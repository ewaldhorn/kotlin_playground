fun isNameValid(name: String): Boolean {
    return when (name) {
        "GRUMPY" -> true
        else -> false
    }
}