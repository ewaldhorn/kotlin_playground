rootProject.name = "GradleJavaKotlinInterop"

